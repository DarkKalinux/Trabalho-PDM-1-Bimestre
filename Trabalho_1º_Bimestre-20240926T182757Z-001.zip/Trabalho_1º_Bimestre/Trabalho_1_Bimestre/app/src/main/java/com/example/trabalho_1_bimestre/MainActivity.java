package com.example.trabalho_1_bimestre;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNome, editTextEmail, editTextIdade, editTextDisciplina, editTextNota1, editTextNota2;
    private TextView textViewResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vincular componentes
        editTextNome = findViewById(R.id.editTextNome);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextIdade = findViewById(R.id.editTextIdade);
        editTextDisciplina = findViewById(R.id.editTextDisciplina);
        editTextNota1 = findViewById(R.id.editTextNota1);
        editTextNota2 = findViewById(R.id.editTextNota2);
        textViewResultado = findViewById(R.id.textViewResultado);
        Button buttonEnviar = findViewById(R.id.buttonEnviar);
        Button buttonLimpar = findViewById(R.id.buttonLimpar);

        // Ação do botão enviar
        buttonEnviar.setOnClickListener(v -> {
            if (validarCampos()) {
                exibirResultado();
            }
        });

        // Ação do botão limpar
        buttonLimpar.setOnClickListener(v -> limparCampos());
    }

    private boolean validarCampos() {
        if (TextUtils.isEmpty(editTextNome.getText())) {
            editTextNome.setError("Nome é obrigatório");
            return false;
        }
        if (TextUtils.isEmpty(editTextEmail.getText()) || !android.util.Patterns.EMAIL_ADDRESS.matcher(editTextEmail.getText()).matches()) {
            editTextEmail.setError("Email inválido");
            return false;
        }
        if (TextUtils.isEmpty(editTextIdade.getText()) || Integer.parseInt(editTextIdade.getText().toString()) <= 0) {
            editTextIdade.setError("Idade inválida");
            return false;
        }
        if (TextUtils.isEmpty(editTextNota1.getText()) || isNotaValida(editTextNota1.getText().toString())) {
            editTextNota1.setError("Nota 1 inválida");
            return false;
        }
        if (TextUtils.isEmpty(editTextNota2.getText()) || isNotaValida(editTextNota2.getText().toString())) {
            editTextNota2.setError("Nota 2 inválida");
            return false;
        }
        return true;
    }

    private boolean isNotaValida(String nota) {
        try {
            float valor = Float.parseFloat(nota);
            return !(valor >= 0) || !(valor <= 10);
        } catch (NumberFormatException e) {
            return true;
        }
    }

    private void exibirResultado() {
        String nome = editTextNome.getText().toString();
        String email = editTextEmail.getText().toString();
        String idade = editTextIdade.getText().toString();
        String disciplina = editTextDisciplina.getText().toString();
        float nota1 = Float.parseFloat(editTextNota1.getText().toString());
        float nota2 = Float.parseFloat(editTextNota2.getText().toString());
        float media = (nota1 + nota2) / 2;

        String resultado = "Nome: " + nome + "\nEmail: " + email + "\nIdade: " + idade +
                "\nDisciplina: " + disciplina + "\nNotas: " + nota1 + ", " + nota2 +
                "\nMédia: " + media + "\n" + (media >= 6 ? "Aprovado" : "Reprovado");

        textViewResultado.setText(resultado);
    }

    private void limparCampos() {
        editTextNome.setText("");
        editTextEmail.setText("");
        editTextIdade.setText("");
        editTextDisciplina.setText("");
        editTextNota1.setText("");
        editTextNota2.setText("");
        textViewResultado.setText("");
    }
}